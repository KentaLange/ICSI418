import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
      Sign Up
      <body>
        <h1>First Name</h1>
        <textarea id="w3review" name="w3review" rows="2" cols="50"></textarea>
        <h1>Last Name</h1>
        <textarea id="w3review" name="w3review" rows="2" cols="50"></textarea>
        <h1>User ID</h1>
        <textarea id="w3review" name="w3review" rows="2" cols="50"></textarea>
        <h1>Password</h1>
        <textarea id="w3review" name="w3review" rows="2" cols="50"></textarea>
        <button onclick="location.href='HW1.html'">
            Submit
        </button>
       
    </body>
    </div>
  );
}